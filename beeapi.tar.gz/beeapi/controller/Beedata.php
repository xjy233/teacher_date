<?php
namespace app\beeapi\controller;
header("Content-type: text/html; charset=utf-8"); 
use think\Controller;

class Beedata extends Controller
{
    
  	//返回日程信息
  	public function getSchedule()
    {
      	//输入
      	$datajason = input('datajason');
      	$datajason = json_decode($datajason);
      	$nameList= $datajason->name;
      	$currunt_time_sta = $datajason->currunt_time_sta;
      	//$nameList = ['莫同','方越坚'];
      	//$currunt_time_sta = '2019-1-1 00:00:00';
        $currunt_time_end = date("Y-n-j G:i:s", strtotime ($currunt_time_sta) + 7*86400);
      
      	//定义返回数组
      	$redataList = array();
      	$a = array();
        $model = model('Beedata');
      	
      	//开始查找每一个老师
      	foreach($nameList as $nameEach){
          $data = $model->getSchedule($name = $nameEach ,$currunt_time_sta,$currunt_time_end);

          //将每一个老师的日程封装成{'上午':['大兴','本部','','','其它','',''],'中午':['大兴','本部','','','其它','',''],'晚上':['大兴','本部','','','其它','','']}
          //初始化早中晚
          $shangwu = array(1,2,3,4,5,6,7);
          $zhongwu = array(1,2,3,4,5,6,7);
          $wanshang = array(1,2,3,4,5,6,7);
          //遍历每一条返回的查询数据
          foreach($data as $each){
              $days = 0;
              $i = 0;
              $hours_start = 0;
              $hours_end = 0;
              $timeStart = $each["timeStart"];
              $timeEnd = $each["timeEnd"];

              $zero1=strtotime ($currunt_time_sta); //当前时间
              $zero2=strtotime ($timeStart);  //开始时间
              $zero3=strtotime ($timeEnd);  //结束时间

              //计算i值
              $i=ceil(($zero2-$zero1)/86400-1); //60s*60min*24h
              //计算结束时间与00:00的日期差值
              $i2=ceil(($zero3-$zero1)/86400 -1); //60s*60min*24h

              //得到查询timestart的0：00：00，例如：2019-1-1 9：00：00  为2019-1-1 0：00：00
              $timeStart_0 = date("Y-n-j G:i:s", $zero1 + $i*86400);
              //得到查询timeend的0：00：00，例如：2019-1-3 9：00：00  为2019-1-3 0：00：00
              $timeEnd_0 = date("Y-n-j G:i:s", $zero1 + $i2*86400);

              //计算结束时间与开始时间的日期差值,如2019-1-1 9：00：00 和2019-1-3 9：00：00 的差值为1，将1-2号填满
              $days=ceil(($i2-$i) -1); //60s*60min*24h

              //计算开始时间是早、中、晚
              //计算开始时间与开始时间00:00的小时差值
              $hours_start=ceil(($zero2-($zero1 + $i*86400))/3600 -1); //60s*60min
              //计算结束时间与结束时间00:00的小时差值
              $hours_end=ceil(($zero3-($zero1 + $i2*86400))/3600 -1); //60s*60min


              //分别填充上、下、晚。规则：2019-1-1 9：00：00 早中晚；1-2 早中晚；2019-1-3 9：00：00 早
              if($days >0){
                  for($next=$i+1;$days>0;$days--){
                      if($next<7){
                      $shangwu[$next] = $each['site'];
                      $zhongwu[$next] = $each['site'];
                      $wanshang[$next] = $each['site'];

                      $next = $next + 1;
                      }
                  }
              }
              if($days + 1 >0){
                //当开始和结束不在同一天
                
                //填充开始那一天的信息
                if($hours_start < 12){
                  $shangwu[$i] = $each['site'];
                  $zhongwu[$i] = $each['site'];
                  $wanshang[$i] = $each['site'];
                }else if(12<=$hours_start && $hours_start<18){
                  $zhongwu[$i] = $each['site'];
                  $wanshang[$i] = $each['site'];
                }else{
                  $wanshang[$i] = $each['site'];
                }
                //填充结束那一天的信息
                if($i2<7){
                  if($hours_end < 12){
                    $shangwu[$i2] = $each['site'];
                  }else if(12<=$hours_end && $hours_end<18){
                    $shangwu[$i2] = $each['site'];
                    $zhongwu[$i2] = $each['site'];
                  }else{
                    $shangwu[$i2] = $each['site'];
                    $zhongwu[$i2] = $each['site'];
                    $wanshang[$i2] = $each['site'];
                  }
                }
              }else{
              	//当开始和结束在同一天
                
                //填充开始那一天的信息
                if($hours_start < 12){
                  $shangwu[$i] = $each['site'];
                  $zhongwu[$i] = $each['site'];
                  $wanshang[$i] = $each['site'];
                }else if(12<=$hours_start && $hours_start<18){
                  $zhongwu[$i] = $each['site'];
                  $wanshang[$i] = $each['site'];
                }else{
                  $wanshang[$i] = $each['site'];
                }
                //填充结束那一天的信息
                if($i2<7){
                  if($hours_end < 12){
                    $shangwu[$i2] = $each['site'];
                    //用$i2对早上开始日期得早中晚进行修正
                    $zhongwu[$i2] = $i2+1;
                    $wanshang[$i2] = $i2+1;
                  }else if(12<=$hours_end && $hours_end<18){
                    $zhongwu[$i2] = $each['site'];
                    $wanshang[$i2] = $i2+1;
                  }else{
                    $wanshang[$i2] = $each['site'];
                  }
                }
              }
            
            
          }//foreach结束

          //返回数据
          $redata = [
              'teachername'=> $nameEach,
              'morning' => $shangwu,
              'afternoon' => $zhongwu,
              'evening' => $wanshang
          ];
          array_push($redataList, $redata);
          
        }
      
      $a = ['teachername'=> 'motong',
              'morning' => ["其他","本部","其他","大兴","本部","其他","其他"],
              'afternoon' => ["本部","本部","其他","大兴","大兴","其他","其他"],
              'evening' => ["其他","其他","本部","其他","本部","其他","其他"]];
      
      	return json($redataList);
    }
  	
  	//插入日程
  	public function insert()
    {
        $teacher_id = input('teacher_id');
      	$name = input('name');
      	$site = input('site');
      	$classes = input('classes');
      	$content = input('content');
      	$TimeStart = input('timeStart');
      	$TimeEnd = input('timeEnd');
      	$zao_zhong_wan = input('zao_zhong_wan');
      	
      	
        $model = model('Beedata');
        $data = $model->insert($teacher_id ,$name ,$site ,$classes ,
                               $content,$TimeStart,$TimeEnd,$zao_zhong_wan);
        #这里必须先转成数组，然后再以json格式返回，不然html格式会出错，导致使用这个接口获得的数据在
      	#json_decode（）时会变成null
      	$html = json_decode($data[0]);
      	return json($html);
    }
  
  	//杨超你们写在这下面	
 	
  
  	public function login(){
      	$name = input('username');
      	$username = json_decode($name);
      	$pwd = input('password');
    	$password = json_decode($pwd);
      	$role = input('role');
      	$type = json_decode($role);
      	//定义返回数组
      	$redataList = array();
      
      	$model = model('Beedata');
        $data = $model->doLogin($username,$password,$type);
        $token = $model->makeToken(32);
      	$adminUserViewId = $data;
      	 //返回数据
          $redata = [
              'adminUserViewId' => $adminUserViewId,
              'token' => $token
          ];
          array_push($redataList, $redata);
        #这里必须先转成数组，然后再以json格式返回，不然html格式会出错，导致使用这个接口获得的数据在
      	#json_decode（）时会变成null
      	//$html = json_decode($data[0]);
      	return json($redataList);
    }
  
   
}