<?php 
namespace app\beeapi\model;

use think\Model;
use think\Db;

class Beedata extends Model
{
  
  	//插入一条日程信息
  	public function insert($teacher_id ,$name ,$site ,$classes ,$content,$TimeStart,$TimeEnd,$zao_zhong_wan)
    {
        $res = Db::table('schedule')->insert(['teacher_id'=>$teacher_id,'name'=>$name,'site'=>$site,'classes'=>	$classes,'timeStart'=>$TimeStart,'timeEnd'=>$TimeEnd,'content'=>$content,'zao_zhong_wan'=>$zao_zhong_wan]);
        return $res;
    }
  
  	//{'上午':[   {'莫同':['大兴','本部','','','其它','','']},  {'郁莲':['大兴','本部','','','其它','','']}   ],
  	// '中午':[   {'莫同':['大兴','本部','','','其它','','']},  {'郁莲':['大兴','本部','','','其它','','']}   ],
  	// ...												}
  	
  	//[{'上午':['大兴','本部','','','其它','',''],'中午':['大兴','本部','','','其它','',''],'晚上':['大兴','本部','','','其它','','']},
  	// {'上午':['大兴','本部','','','其它','',''],'中午':['大兴','本部','','','其它','',''],'晚上':['大兴','本部','','','其它','','']},]
  	
  	//提供日程公示信息，注意要转化成数组,time为2019-1-1 00:00:00格式
  	public function getSchedule($name = '莫同',$currunt_time_sta='2019-1-1 00:00:00',$currunt_time_end='2019-1-8 00:00:00')
    {
      //查找符合要求的信息段
      $result	=	Db::name('schedule')
        ->where([
          'timeStart'   =>	['between',[$currunt_time_sta,$currunt_time_end]],
          'name' =>	['=',$name],
        ])->select();
      //dump($result);

      return $result;
    }
  	
  
  	//杨超你们写在这下面
    // 处理登录逻辑
    public function doLogin($username,$password,$type)
    {		
      	if($type=="student"){
        	$result	=	Db::name('student')
              ->where([
                'user_name' =>	['=',$username],
                'user_pwd' => ['=',$password],
              ])->select();  
        }else{
        	$result	=	Db::name('teacher')
              ->where([
                'user_name' =>	['=',$username],
                'user_pwd' => ['=',$password],
              ])->select();  
        }
        	//查找符合要求的信息段
                      
      return $result;
    }

     public function makeToken($param)
    {
       	 $str="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
          $key = "";
          for($i=0;$i<$param;$i++)
           {
               $key .= $str{mt_rand(0,32)};    //生成php随机数
           }
        //随机抽取32位字符串方法，保存在common.php中
        $randChar = $key;
        //时间戳
        $timestamp = time();
        //配置中的盐值
        $salt = config('secret.token_salt');
        //拼接之后sha1加密
        return sha1($randChar . $timestamp . $salt);
    }
  	
}